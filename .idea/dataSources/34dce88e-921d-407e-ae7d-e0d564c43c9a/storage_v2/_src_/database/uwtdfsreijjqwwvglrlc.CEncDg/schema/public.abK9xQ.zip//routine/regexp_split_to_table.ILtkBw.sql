create function regexp_split_to_table(citext, citext) returns SETOF text
    immutable
    strict
    parallel safe
    language sql
as
$$
    SELECT pg_catalog.regexp_split_to_table( $1::pg_catalog.text, $2::pg_catalog.text, 'i' );
$$;

alter function regexp_split_to_table(citext, citext) owner to nhost_admin;

